﻿using System;
using System.Collections.Generic;
using System.IO;
using Xamarin.Forms;

namespace VehicleApp
{
    public partial class SigPOP : ContentPage
    {
        public SigPOP()
        {
            InitializeComponent();
        }



        async void Button_Clicked(System.Object sender, System.EventArgs e)

        {
            Stream sigImage = await PadView.GetImageStreamAsync(SignaturePad.Forms.SignatureImageFormat.Png);
            if (sigImage == null)
            {
                return;
            }
            BinaryReader br = new BinaryReader(sigImage);
            br.BaseStream.Position = 0;
            Byte[] All = br.ReadBytes((int)sigImage.Length);
            byte[] image = (byte[])All;
            string base64StringSignature = Convert.ToBase64String(image);


            var check = await DisplayAlert("Message", "Are you satisfied with your signature", "YES", "NO");

            if (check == true)
            {

                Application.Current.Properties["SignatureID"] = base64StringSignature;
                await Navigation.PopAsync();
            }

            else
            {
                return;
            }
        }

        async void ButtonCancel_Clicked(System.Object sender, System.EventArgs e)
        {

            await Navigation.PopAsync();

        }

    }

}

