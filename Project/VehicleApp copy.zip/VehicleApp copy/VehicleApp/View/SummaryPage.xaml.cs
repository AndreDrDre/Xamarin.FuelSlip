﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using HelloWorld;
using Rg.Plugins.Popup.Extensions;
using SQLite;
using VehicleApp.Models;
using Xamarin.Forms;
using Xamarin.Essentials;
using VehicleApp.View;

namespace VehicleApp
{
    public partial class SummaryPage : ContentPage
    {
        private SQLiteAsyncConnection _connectionPaySlip;
        private ObservableCollection<PaySlipDB> _slip;
        public List<Capturefrom_DB> ListDB = new List<Capturefrom_DB>();

        public SummaryPage()
        {
            InitializeComponent();
            welcomelbl.Text = "Welcome ";
            _connectionPaySlip = DependencyService.Get<ISQLiteDB>().GetConnection();
        }
        protected override async void OnAppearing()
        {
            await _connectionPaySlip.CreateTableAsync<PaySlipDB>();

            var holder = Application.Current.Properties["EmailGUID"].ToString();

            var query = _connectionPaySlip.Table<PaySlipDB>().Where(v => v.Email == holder);
            var querypayslip = await query.ToListAsync();
            int check = await query.CountAsync();

            if (check >= 1)
            {
                _slip = new ObservableCollection<PaySlipDB>(querypayslip); //for the purpose of display

                for (int i = 0; i < _slip.Count; i++)
                {

                    ImageSource imagesourceSig = null;
                    ImageSource imagesourceSlip = null;

                    byte[] Base64StreamSignature = Convert.FromBase64String(_slip[i].Signature);
                    imagesourceSig = ImageSource.FromStream(() => new MemoryStream(Base64StreamSignature));

                    byte[] Base64StreamPaySlip = Convert.FromBase64String(_slip[i].PaySlip);
                    imagesourceSlip = ImageSource.FromStream(() => new MemoryStream(Base64StreamPaySlip));

                    var dbAdder = new Capturefrom_DB("Reg_Number: " + _slip[i].RegNumber, "Odo_Reading: " + _slip[i].OdemeterRead, _slip[i].Date, imagesourceSlip, imagesourceSig);
                    ListDB.Add(dbAdder);
                }

                SummaryView.ItemsSource = ListDB; //= to my new list

            }
            base.OnAppearing();
        }

        async void ButtonBack_Clicked(System.Object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new MyPage());
        }

        async void AddButton_Clicked(System.Object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new AddSlip());
        }

        async void SummaryView_ItemSelected(System.Object sender, Xamarin.Forms.SelectedItemChangedEventArgs e)
        {
            int itemcounter = e.SelectedItemIndex;
            ImageSource imageSlip = ListDB[itemcounter].PaySlip_cap;
            await Navigation.PushPopupAsync(new PopUpImage(imageSlip));
        }





    }
}
