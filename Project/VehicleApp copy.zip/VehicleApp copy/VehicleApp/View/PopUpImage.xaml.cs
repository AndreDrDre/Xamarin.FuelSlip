﻿using System;
using System.Collections.Generic;
using System.IO;
using Rg.Plugins.Popup.Extensions;
using Rg.Plugins.Popup.Pages;
using Rg.Plugins.Popup.Services;
using Xamarin.Forms;



namespace VehicleApp.View
{
    public partial class PopUpImage : PopupPage
    {

        public PopUpImage(ImageSource _image)
        {

            InitializeComponent();
            ImageSlip.Source = _image;
        }


        async void BackPOP_Clicked(System.Object sender, System.EventArgs e)
        {
            await Navigation.PushAsync(new SummaryPage());
            await Navigation.PopPopupAsync();
        }
    }
}
