﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using HelloWorld;
using Plugin.Media;
using Plugin.Media.Abstractions;
using SQLite;
using VehicleApp.Models;
using Xamarin.Forms;
using Xamarin.Essentials;

namespace VehicleApp.View

{
    public partial class AddSlip : ContentPage
    {
        private SQLiteAsyncConnection _connectionPaySlip;
        //private ImageSource payslip;
        string signature;
       // string payslip;
        public string base64Payslip;

        public AddSlip()
        {
            InitializeComponent();
            CameraButton.Source = ImageSource.FromResource("VehicleApp.Images.CameraButton.png");
            Submit.IsEnabled = false;
            backBTN.IsEnabled = true;
            _connectionPaySlip = DependencyService.Get<ISQLiteDB>().GetConnection();
            car.Source = ImageSource.FromResource("VehicleApp.Images.Picutre.png");

        }

        protected override async void OnAppearing()
        {
            await _connectionPaySlip.CreateTableAsync<PaySlipDB>();
            base.OnAppearing();

        }

        async void BackButton_Clicked(System.Object sender, System.EventArgs e)
        {

            await Navigation.PushAsync(new SummaryPage());
        }

        async void SubmitButton_Clicked(System.Object sender, System.EventArgs e)
        {

            //cant click submit without creating a signature.
            signature = (string)Application.Current.Properties["SignatureID"]; //as a base 64 string

            string email = Application.Current.Properties["EmailGUID"].ToString();

            if (signature != null)
            {

                var payslipIN = new PaySlipDB(_Reg.Text, _Odemeter.Text, _date.Date, base64Payslip, namelbl.Text, signature, email);  //We need to pass the pay slip via the camera
                var result = await DisplayAlert("Message", "Would you like to add another entry", "YES", "NO");

                if (result == true)
                {

                    namelbl.Text = "";
                    _Reg.Text = "";
                    _Odemeter.Text = "";
                    _date.Date = DateTime.Now;
                    namelbl.Placeholder = "Name";
                    _Reg.Placeholder = "Vehicle Registration";
                    _Odemeter.Placeholder = "Enter Odemeter Reading";
                    Submit.IsEnabled = false;

                    await _connectionPaySlip.InsertAsync(payslipIN); //Add entry in the database
                    await DisplayAlert("Message", "Your entry has been copied to the database", "OK");
                    return;

                }
                else
                {
                    await _connectionPaySlip.InsertAsync(payslipIN);
                    await DisplayAlert("Message", "Your entry has been copied to the database", "OK");
                    await Navigation.PushAsync(new SummaryPage());
                }
            }
            else
            {

                await DisplayAlert("Message", "Please take a pciture first", "OK");


            }
        }

        private async void CameraButton_Clicked(System.Object sender, System.EventArgs e)
        {


            await CrossMedia.Current.Initialize();

            if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakePhotoSupported)
            {
                await DisplayAlert("No Camera", ":( No camera available.", "OK");
                return;
            }

            var file = await CrossMedia.Current.TakePhotoAsync(new Plugin.Media.Abstractions.StoreCameraMediaOptions
            {
                Directory = "Images",
                Name = "Capture.jpg"
            });

            if (file == null)
                return;

            // await DisplayAlert("File Location", file.Path, "OK");


            using (MemoryStream ms = new MemoryStream())
            {
                var stream = file.GetStream();
                var bytes = new byte[stream.Length];
                await stream.ReadAsync(bytes, 0, (int)stream.Length);
                base64Payslip = Convert.ToBase64String(bytes);
                file.Dispose();
            }
            backBTN.IsEnabled = false;
            Submit.IsEnabled = true;
            await Navigation.PushAsync(new SigPOP());
        }
    }

}




