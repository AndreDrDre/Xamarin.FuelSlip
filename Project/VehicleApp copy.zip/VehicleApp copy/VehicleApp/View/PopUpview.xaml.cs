﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using HelloWorld;
using Rg.Plugins.Popup.Extensions;
using Rg.Plugins.Popup.Pages;
using Rg.Plugins.Popup.Services;
using SQLite;
using VehicleApp.Models;
using Xamarin.Forms;

namespace VehicleApp.View

{
    public partial class PopUpview : PopupPage
    {
        private SQLiteAsyncConnection _connection;

        public PopUpview()
        {
            InitializeComponent();
            _connection = DependencyService.Get<ISQLiteDB>().GetConnection();
        }

        protected override async void OnAppearing()
        {
            await _connection.CreateTableAsync<EmployeeDB>();
            base.OnAppearing();

        }

        async void LoginButton_Clicked(System.Object sender, System.EventArgs e)
        {

            var query = _connection.Table<EmployeeDB>().Where(v => v.Email == EmailInput.Text.ToLower());
            int check = await query.CountAsync();

            var employee = await query.ToListAsync();

            if (check >= 1)
            {

                if (employee[0].Password == PasswordInput.Text)
                {
                    Application.Current.Properties["EmailGUID"] = EmailInput.Text.ToLower();
                    await Navigation.PushAsync(new SummaryPage());
                    await Navigation.PopPopupAsync(); //This has to be PopPopupasync because i am closing a popup 
                }
                else
                {
                    await DisplayAlert("Message", "You have entered an incorrect username or password", "OK");
                    EmailInput.Text = "";
                    PasswordInput.Text = "";

                }

            }
            else
            {
                await DisplayAlert("Message", "You have not registered yet", "OK");
                EmailInput.Text = "";
                PasswordInput.Text = "";
                await Navigation.PushAsync(new RegisterPage());
                await Navigation.PopPopupAsync();
            }
        }

        async void Back_Clicked(System.Object sender, System.EventArgs e)
        {

            await Navigation.PopPopupAsync();
        }
    }
}
