﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using HelloWorld;
using Rg.Plugins.Popup.Extensions;
using Rg.Plugins.Popup.Services;
using SQLite;
using VehicleApp.Models;
using Xamarin.Forms;


namespace VehicleApp.View
{
    public partial class MyPage : ContentPage
    {
        private SQLiteAsyncConnection _connection; //connection varibale
        private ObservableCollection<EmployeeDB> _EmployeeDelete;
        private ObservableCollection<PaySlipDB> _PaySlipDelete;

        public MyPage()
        {
            InitializeComponent();
            car.Source = ImageSource.FromResource("VehicleApp.Images.Picutre.png");
            _connection = DependencyService.Get<ISQLiteDB>().GetConnection();
        }
        async void Register_Clicked(System.Object sender, System.EventArgs e)
        {

            await Navigation.PushAsync(new RegisterPage());

        }

        async void Login_Clicked(System.Object sender, System.EventArgs e)
        {
            await Navigation.PushPopupAsync(new PopUpview());
        }

        protected override async void OnAppearing()
        {
            //create database for payslips

            await _connection.CreateTableAsync<PaySlipDB>(); //creating a Table in sql lite
            var payslip = await _connection.Table<PaySlipDB>().ToListAsync(); //sets a variable = the list in memeory
            _PaySlipDelete = new ObservableCollection<PaySlipDB>(payslip);

            await _connection.CreateTableAsync<EmployeeDB>(); //creating a Table in sql lite
            var Employee = await _connection.Table<EmployeeDB>().ToListAsync(); //sets a variable = the list in memeory
            _EmployeeDelete = new ObservableCollection<EmployeeDB>(Employee);

            base.OnAppearing();

        }

        //async void DeleteDataBase_Clicked(System.Object sender, System.EventArgs e)
        //{

        //    for (int i = 0; i < _EmployeeDelete.Count; i++)
        //    {
        //        var delete = _EmployeeDelete[i];
        //        await _connection.DeleteAsync(delete);
        //        _EmployeeDelete.Remove(delete);
        //    }

        //    for (int j = 0; j < _PaySlipDelete.Count; j++)
        //    {


        //        var deleteSlip = _PaySlipDelete[j];
        //        await _connection.DeleteAsync(deleteSlip);
        //        _PaySlipDelete.Remove(deleteSlip);

        //    }


        }
    }

   








