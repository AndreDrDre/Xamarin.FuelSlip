﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using HelloWorld;
using SQLite;
using VehicleApp.Models;
using VehicleApp.View;
using Xamarin.Forms;

namespace VehicleApp
{

    public partial class RegisterPage : ContentPage
    {
        private SQLiteAsyncConnection _connection;

        public RegisterPage()
        {
            InitializeComponent();
            _connection = DependencyService.Get<ISQLiteDB>().GetConnection();
        }


        protected override async void OnAppearing()
        {
            await _connection.CreateTableAsync<EmployeeDB>(); //create a table of Employee if not exists
            base.OnAppearing();

        }

        async void Button_Clicked(System.Object sender, System.EventArgs e)
        {
            await Navigation.PopAsync();
        }

        async void ButtonCreate_Clicked(System.Object sender, System.EventArgs e)
        {

            var employee = new EmployeeDB(_Name.Text, _Email.Text.ToLower(), _Password.Text); //instantiate the class EmployeeDB and populate the constructor
            var query = _connection.Table<EmployeeDB>().Where(v => v.Email == _Email.Text);
            int check = await query.CountAsync();

            if (check == 0)
            {

                if (_Password.Text == _confirmPassword.Text)
                {
                    await _connection.InsertAsync(employee); // insert an entry into the database
                    //await DisplayAlert("Message", "You have been successfully added to the database", "OK");
                    await Navigation.PushAsync(new MyPage());
                }

                else
                {
                    _confirmPassword.Text = "";
                    await DisplayAlert("Message", "Your password did not match, try again", "OK");
                }
            }

            else
            {
                await DisplayAlert("Message", "You have already been added to the database", "OK");
                _Name.Text = "";
                _Email.Text = "";
                _Password.Text = "";
                _confirmPassword.Text = "";

            }

        }

        protected override bool OnBackButtonPressed()
        {
            return true;
        }
    }
}
