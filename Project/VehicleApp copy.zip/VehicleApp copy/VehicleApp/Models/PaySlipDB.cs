﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using SQLite;
using Xamarin.Forms;
namespace VehicleApp.Models
{
    [Table("PaySlip")]
    public class PaySlipDB 
    {
        public int? ServerID { get; set; }

        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }


        [MaxLength(255)]
        [Indexed]

        public string RegNumber { get; set; }
        public string OdemeterRead { get; set; }
        public DateTime Date { get; set; }
        public string PaySlip { get; set; }
        public string Name { get; set; }
        public string Signature { get; set; }
        public string Email { get; set; }

       // public event PropertyChangedEventHandler PropertyChanged;



        public PaySlipDB(string regNumber, string odemeterRead, DateTime date, string paySlip, string name, string signature, string email)
        {

            this.RegNumber = regNumber.ToString();
            this.OdemeterRead = odemeterRead;
            this.Date = date;
            this.PaySlip = paySlip;
            this.Name = name;
            this.Signature = signature;
            this.Email = email;
        }

        public PaySlipDB()
        {

        }

        
    }
}


   

   



