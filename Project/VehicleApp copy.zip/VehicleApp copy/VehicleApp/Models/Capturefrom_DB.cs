﻿using System;
using Xamarin.Forms;

namespace VehicleApp.Models
{
    public class Capturefrom_DB
    {

        public string RegNumber_cap { get; set; }
        public string OdemeterRead_cap { get; set; }
        public DateTime Date_cap { get; set; }
        public ImageSource PaySlip_cap { get; set; }
        public ImageSource Signature_cap { get; set; }

        public Capturefrom_DB(string _regNumber_cap, string _odemeterRead_cap, DateTime _date_cap, ImageSource _paySlip_cap, ImageSource _signature_cap)
        {

            this.RegNumber_cap = _regNumber_cap;
            this.OdemeterRead_cap = _odemeterRead_cap;
            this.Date_cap = _date_cap;
            this.PaySlip_cap = _paySlip_cap;
            this.Signature_cap = _signature_cap;



        }
    }
}
