﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using SQLite;

namespace VehicleApp.Models
{
    [Table("Employee")]
    public class EmployeeDB 
    {
      //  public event PropertyChangedEventHandler PropertyChanged;

        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        [MaxLength(255)]
        [Indexed]
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }


        public EmployeeDB(string _name, string _email, string _password)
        {
            this.Name = _name;
            this.Email = _email;
            this.Password = _password;

        }

        public EmployeeDB()
        {

        }


    }
}





