﻿using SQLite;

namespace HelloWorld
{
    public interface ISQLiteDB
    {
        SQLiteAsyncConnection GetConnection();
    }
}
